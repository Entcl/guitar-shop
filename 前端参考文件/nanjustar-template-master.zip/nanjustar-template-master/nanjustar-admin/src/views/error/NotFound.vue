<template>
<div>
  <lottie-player
      src="https://assets6.lottiefiles.com/packages/lf20_sdd6siet.json"
      background="transparent"
      speed="1"
      loop
      autoplay
  >
  </lottie-player>
</div>
</template>

<script>
export default {
  name: "NotFount"
}
</script>

<style scoped>

</style>