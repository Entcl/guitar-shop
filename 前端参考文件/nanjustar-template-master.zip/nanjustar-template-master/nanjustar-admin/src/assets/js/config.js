export default {
    TENCENT_CAPTCHA: "2091917761",
}