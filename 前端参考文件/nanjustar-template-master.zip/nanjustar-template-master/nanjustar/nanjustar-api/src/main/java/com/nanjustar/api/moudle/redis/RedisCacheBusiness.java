package com.nanjustar.api.moudle.redis;

/**
 * Redis 缓存部分数据
 */
public interface RedisCacheBusiness {

    /**
     * 缓存图标信息
     */
    void cacheIconList();
}
