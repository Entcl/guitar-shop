package com.nanjustar.api.moudle.security.api;

import com.nanjustar.api.moudle.security.entity.Role;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author nanjustar
 * @since 2021-11-13
 */
public interface RoleService extends IService<Role> {

}
