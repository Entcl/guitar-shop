package com.nanjustar.business.annotation;

public @interface LoginLog {
}
