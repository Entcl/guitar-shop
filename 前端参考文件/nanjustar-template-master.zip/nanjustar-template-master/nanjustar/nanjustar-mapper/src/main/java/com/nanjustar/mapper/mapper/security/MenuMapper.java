package com.nanjustar.mapper.mapper.security;

import com.nanjustar.api.moudle.security.entity.Menu;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author nanjustar
 * @since 2021-11-13
 */
public interface MenuMapper extends BaseMapper<Menu> {

}
