### 安装

```bash
npm install -g @vue/cli@4.5.15
```

