```bash
npm config get registry
```

```bash
npm config set registry=https://registry.npm.taobao.org
```

