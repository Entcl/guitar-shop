#### 安装

```bash
 npm install bootstrap@5.2.0-beta1
```

#### 引入在main.js

```js
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js'
```

